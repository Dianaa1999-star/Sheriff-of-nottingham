package com.tema1.players;


public final class Constants {
    public static  final int NR_MAX_CARDS = 10;
    public static  final int START_COINS = 80;
    public static final int MAX_CARDS_TYPE = 25;
    public static final int NR_MAX_BAG = 8;
    public static final int MAX_BRIBE = 10;
    public static final int MIN_BRIBE = 5;
    public static final int NR_MAX_LOW_CASH = 2;
    // add/delete any constants you think you may use
}